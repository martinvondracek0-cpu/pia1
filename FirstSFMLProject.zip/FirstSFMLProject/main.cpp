#include <SFML/Graphics.hpp>
#include <iostream>
#include <vector>
#include <cmath>
#include <thread>
#include <mutex>
#include <string>
#include <atomic>
#include <chrono>

///////////////////////////////////////////////////////////////
//  NUMERICKÉ JÁDRO - ŘEŠENÍ PDE VE VÝMĚNÍKU, VČETNĚ PARAMETRŮ VÝMĚNÍKU
///////////////////////////////////////////////////////////////

class Parametry {
public:
    double U = 320.0;
    double a_surface = 80.0;
    double D_outer = 0.5;
    double D_inner = 0.25;

    double rho1 = 1000.0;
    double rho2 = 1000.0;
    double cp1  = 4200.0;
    double cp2  = 4200.0;

    double u1 = 1.0;
    double u2 = 1.0;

    double mdot1 = 0.0;
    double mdot2 = 0.0;
    double W1 = 0.0;
    double W2 = 0.0;

    Parametry() {
        const double PI = std::acos(-1.0);
        double A2 = PI * D_inner * D_inner / 4.0;
        double A1 = PI * (D_outer*D_outer - D_inner*D_inner) / 4.0;
        mdot1 = rho1 * A1 * u1;
        mdot2 = rho2 * A2 * u2;
        W1 = mdot1 * cp1;
        W2 = mdot2 * cp2;

        if (W1 == 0.0) W1 = 1e-12;
        if (W2 == 0.0) W2 = 1e-12;
    }

    double C1() const { return (U * a_surface) / W1; }
    double C2() const { return (U * a_surface) / W2; }
    double maxVelocity() const { return std::max(u1, u2); }
};

///////////////////////////////////////////////////////////////
// SDÍLENÁ DATA MEZI INTERFACEM A SIMULACÍ
///////////////////////////////////////////////////////////////

struct SharedInput {
    double T1_in = 330.0; // T1 se ohřívá, tzn. trubka vnitřní
    double T2_in = 360.0; // T2 se ochlazuje, tzn. trubka vnější
    std::mutex mtx;
};

///////////////////////////////////////////////////////////////
// NUMERICKÝ ŘEŠIČ – SEPARÁTNÍ THREAD
///////////////////////////////////////////////////////////////

class Solver {
public:
    const double L = 40.0;
    const int Nx = 201;
    const double totalTime = 999999.0;

    std::vector<double> x;
    std::vector<double> T1, T2;

    Parametry P;
    double dx, dt;

    SharedInput* inputs;

    std::atomic<bool> running{true};

    Solver(SharedInput* ptr) : inputs(ptr) {
        dx = L / (Nx - 1);
        double CFL = 0.5;
        dt = CFL * dx / P.maxVelocity();

        x.resize(Nx);
        T1.resize(Nx);
        T2.resize(Nx);
        for(int i=0;i<Nx;i++){
            x[i] = i * dx;
            T1[i] = 300.0;
            T2[i] = 350.0;
        }
    }

    void stop() { running.store(false); }

    void run() {
        std::vector<double> T1_new(Nx), T2_new(Nx);

        while(running.load()) {
            double T1_in_local, T2_in_local;
            {
                std::lock_guard<std::mutex> lg(inputs->mtx);
                T1_in_local = inputs->T1_in;
                T2_in_local = inputs->T2_in;
            }

            for(int i=1;i<Nx;i++){
                double dT1dx = (T1[i] - T1[i-1]) / dx;
                double dT2dx = (T2[i] - T2[i-1]) / dx;

                T1_new[i] = T1[i] + dt * ( -P.u1*dT1dx + P.C1()*(T2[i] - T1[i]) );
                T2_new[i] = T2[i] + dt * ( -P.u2*dT2dx + P.C2()*(T1[i] - T2[i]) );
            }

            T1_new[0] = T1_in_local;
            T2_new[0] = T2_in_local;

            T1.swap(T1_new);
            T2.swap(T2_new);

            std::this_thread::sleep_for(std::chrono::milliseconds(10));
        }
    }
};

///////////////////////////////////////////////////////////////
// INPUT POLE
///////////////////////////////////////////////////////////////

class TextField {
public:
    sf::RectangleShape box;
    sf::Text text;
    bool active = false;
    std::string buffer;

    TextField(float x, float y, float w, float h, sf::Font& font)
        : text(font)
    {
        box.setPosition({x, y});
        box.setSize({w, h});
        box.setFillColor(sf::Color(240, 240, 240)); // Tady se upravujou barvy pozadí inputů
        box.setOutlineColor(sf::Color::Black);
        box.setOutlineThickness(2);

        text.setFillColor(sf::Color::Black);
        text.setPosition({x + 5, y + 3});
    }

    void draw(sf::RenderWindow& win) {
        win.draw(box);
        win.draw(text);
    }

    void activate(bool state) {
        active = state;
        box.setOutlineColor(state ? sf::Color::Blue : sf::Color::Black);
    }

    void handleEvent(const sf::Event& event) {
    if (!active) return;

    if (auto textEntered = event.getIf<sf::Event::TextEntered>()) {
        auto unicode = textEntered->unicode;
        if (unicode == 8) {
            if (!buffer.empty()) buffer.pop_back();
        }
        else if (unicode >= '0' && unicode <= '9') {
            buffer.push_back(static_cast<char>(unicode));
        }
        else if (unicode == '.') {
            if (buffer.find('.') == std::string::npos)
                buffer.push_back('.');
        }
        text.setString(buffer);
    }
}

    double value() const {
        if (buffer.empty()) return 0.0;
        try {
            if (buffer == "." || buffer.back() == '.') return 0.0;
            return std::stod(buffer);
        }
        catch (...) {
            return 0.0;
        }
    }
};

///////////////////////////////////////////////////////////////
// MAIN ČÁST
///////////////////////////////////////////////////////////////

int main() {
    sf::Font font;
    if(!font.openFromFile("arial.ttf")) {
        std::cerr << "Nelze načíst font 'arial.ttf' - musí být ve složce programu.\n";
        return 1;
    }

    SharedInput shared;
    Solver solver(&shared);

    std::thread simThread(&Solver::run, &solver);

    sf::RenderWindow inputWin(sf::VideoMode({350u, 300u}), "Vstupy");
    sf::RenderWindow graphWin(sf::VideoMode({900u, 500u}), "Graf teplot");

    TextField T1in(20,40,130,40,font);
    TextField T2in(20,120,130,40,font);

    // Nastavení textu T1 vstupní teploty
    sf::Text label1{font};
    label1.setString("T1 (cervena) - nenech prazdne!!!");
    label1.setFont(font);
    label1.setCharacterSize(22);
    label1.setPosition({20, 10});
    label1.setFillColor(sf::Color::Red);

    // Nastavení textu T2 vstupní teploty
    sf::Text label2{font};
    label2.setString("T2 (modra) - nenech prazdne!!!");
    label2.setFont(font);
    label2.setCharacterSize(22);
    label2.setPosition({20, 90});
    label2.setFillColor(sf::Color::Blue);

    // Čudlík s nápisem ENTER
    sf::RectangleShape button(sf::Vector2f(120.f,50.f));
    button.setPosition({180.f,200.f});
    button.setFillColor(sf::Color(200,200,255));
    button.setOutlineThickness(2);
    button.setOutlineColor(sf::Color::Black);

    sf::Text buttontxt{font};
    buttontxt.setString("ENTER");
    buttontxt.setFont(font);
    buttontxt.setCharacterSize(24);
    buttontxt.setPosition({200,210});

    while (inputWin.isOpen() || graphWin.isOpen()) {

    
    while (auto eOpt = inputWin.pollEvent()) {
        auto& e = *eOpt;

        if (e.getIf<sf::Event::Closed>()) {
            inputWin.close();
        }

        if (auto mouse = e.getIf<sf::Event::MouseButtonPressed>()) {
            sf::Vector2f mpos = inputWin.mapPixelToCoords(sf::Mouse::getPosition(inputWin));

            T1in.activate(T1in.box.getGlobalBounds().contains(mpos));
            T2in.activate(T2in.box.getGlobalBounds().contains(mpos));

            if (button.getGlobalBounds().contains(mpos)) {
                std::lock_guard<std::mutex> lg(shared.mtx);
                shared.T1_in = T1in.value();
                shared.T2_in = T2in.value();
            }
        }

        T1in.handleEvent(e);
        T2in.handleEvent(e);
    }

    
    if (inputWin.isOpen()) {
        inputWin.clear({230,230,230});
        inputWin.draw(label1);
        inputWin.draw(label2);
        T1in.draw(inputWin);
        T2in.draw(inputWin);
        inputWin.draw(button);
        inputWin.draw(buttontxt);
        inputWin.display();
    }

    
    while (auto gOpt = graphWin.pollEvent()) {
        auto& g = *gOpt;
        if (g.getIf<sf::Event::Closed>()) graphWin.close();
    }

    // Grafickej output do vyskakovacího okna (škálovaný a počítaný z hodnot hl. výp. cyklu)
    if (graphWin.isOpen()) {
    graphWin.clear(sf::Color::White);

    float marginLeft = 50.f;
    float marginBottom = 450.f;
    float plotWidth = 800.f; // graf bude 800 px široký
    float plotHeight = 400.f; // graf bude 400 px vysoký

    // Horizontální osa (x)
    sf::RectangleShape xaxis{{plotWidth, 2.f}};
    xaxis.setPosition({marginLeft, marginBottom});
    xaxis.setFillColor(sf::Color::Black);
    graphWin.draw(xaxis);

    // Vertikální osa (y)
    sf::RectangleShape yaxis{{2.f, plotHeight}};
    yaxis.setPosition({marginLeft, marginBottom - plotHeight});
    yaxis.setFillColor(sf::Color::Black);
    graphWin.draw(yaxis);

    // Popisky osy Y po 50 K
    for (int T = 0; T <= 500; T += 50) { // max 500 K, můžeš upravit
        float yPos = marginBottom - (T - 0) * (plotHeight / 500.f); // lineární škála
        sf::Text tlabel{font};
        tlabel.setFont(font);
        tlabel.setString(std::to_string(T));
        tlabel.setCharacterSize(16);
        tlabel.setFillColor(sf::Color::Black);
        tlabel.setPosition({5.f, yPos - 10.f});
        tlabel.setFillColor(sf::Color::Black);
        tlabel.setPosition({5.f, yPos - 10.f});
        graphWin.draw(tlabel);

        // Malá čárka na ose
        sf::RectangleShape tick{{5.f, 2.f}};
        tick.setPosition({marginLeft - 5.f, yPos});
        tick.setFillColor(sf::Color::Black);
        graphWin.draw(tick);
    }

    // Popisek konce osy Y (max teplota)
    int T_max = 500;

    sf::Text ylabelEnd{font};
    ylabelEnd.setFont(font);
    ylabelEnd.setString(std::to_string(T_max) + " K");
    ylabelEnd.setCharacterSize(16);
    ylabelEnd.setFillColor(sf::Color::Black);
    ylabelEnd.setPosition({marginLeft + 10.f, marginBottom - plotHeight - 10.f}); // napravo od konce osy
    graphWin.draw(ylabelEnd);

    // Popisky osy X po 5 m
    for (int x = 0; x <= static_cast<int>(solver.L); x += 5) {
    float xPos = marginLeft + static_cast<float>(x) * (plotWidth / solver.L); // škálování na délku L

    sf::Text xlabel{font};
    xlabel.setFont(font);
    xlabel.setString(std::to_string(x));
    xlabel.setCharacterSize(16);
    xlabel.setFillColor(sf::Color::Black);
    xlabel.setPosition({xPos - 8.f, marginBottom + 5.f}); // posunutí pod osu
    graphWin.draw(xlabel);

    // Malá čárka na ose
    sf::RectangleShape tick{{2.f, 5.f}};
    tick.setPosition({xPos, marginBottom});
    tick.setFillColor(sf::Color::Black);
    graphWin.draw(tick);
    }

    // Popisek konce osy X (L)
    sf::Text xlabelEnd{font};
    xlabelEnd.setFont(font);
    xlabelEnd.setString(std::to_string(static_cast<int>(solver.L)) + " m");
    xlabelEnd.setCharacterSize(16);
    xlabelEnd.setFillColor(sf::Color::Black);
    xlabelEnd.setPosition({marginLeft + plotWidth - 25.f, marginBottom + 20.f});
    graphWin.draw(xlabelEnd);

    // Vertex array pro teplotní křivky
    sf::VertexArray curve1(sf::PrimitiveType::LineStrip, solver.Nx);
    sf::VertexArray curve2(sf::PrimitiveType::LineStrip, solver.Nx);

    for (int i = 0; i < solver.Nx; i++) {
        float X = marginLeft + static_cast<float>(i * plotWidth / solver.Nx * (solver.L / solver.L)); // škálování na délku L
        float Y1 = marginBottom - static_cast<float>((solver.T1[i] - 0) * (plotHeight / 500.f));
        float Y2 = marginBottom - static_cast<float>((solver.T2[i] - 0) * (plotHeight / 500.f));

        curve1[i].position = {X, Y1};
        curve1[i].color = sf::Color::Red;

        curve2[i].position = {X, Y2};
        curve2[i].color = sf::Color::Blue;
    }
    graphWin.draw(curve1);
    graphWin.draw(curve2);
    graphWin.display();
    }


    // Konec grafickýho outputu

    if (!inputWin.isOpen() && !graphWin.isOpen()) break;
    std::this_thread::sleep_for(std::chrono::milliseconds(10));
    }

    solver.stop();
    if(simThread.joinable()) simThread.join();
    return 0;
}