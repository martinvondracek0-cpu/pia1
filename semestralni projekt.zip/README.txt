// Příkazy na kompilaci:

1. Příkaz:

g++ -c main.cpp -I"C:\Users\vondr\Documents\libraries\SFML-3.0.2\include"



2. Příkaz:

g++ main.o -o main -L"C:\Users\vondr\Documents\libraries\SFML-3.0.2\lib" -lsfml-graphics -lsfml-window -lsfml-system



// Postup provedení a aplikace úprav kódu (platí pro moje vlastní PC, cesty pro include a lib se budou lišit podle cesty ke staženým knihovnám SFML):

1. ve složce FirstSFMLProject smaž soubory "main.o" a "main.exe"

2. Proveď úpravy v kódu v souboru "main.cpp"

3. Po úpravách ulož změny v souboru "main.cpp"

4. Do terminálu v editoru vlož 1. příkaz a stiskni klávesu ENTER

5. Poté do terminálu v editoru vlož 2. příkaz a stiskni klávesu ENTER

6. Nakonec do terminálu napiš "./main" (bez uvozovek) a stiskni klávesu ENTER (spustí main.exe soubor, měla by se otevřít 2 okna)

